export interface Parking {
    id: string;
    name: string;
    city: string;
}