export interface Client {
    id: string;
    email: string;
}
