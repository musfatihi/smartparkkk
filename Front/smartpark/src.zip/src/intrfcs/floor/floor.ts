export interface Floor {
    id:string;
    nbr:number;
    parking:string;
}